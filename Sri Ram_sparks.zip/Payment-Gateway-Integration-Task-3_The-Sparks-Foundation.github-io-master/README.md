# Payment-Gateway-Integration-Task-3_The-Sparks-Foundation.github-io
A simple Responsive website where payment gateway is integrated.

There will be a simple donate button on the homepage. On clicking the donate button,
the user will land on the payment page where the user can select the choice of a gateway 
than the amount to be paid and the payment type, e.g. credit card, Paypal, etc.

Once the payment is done an invoice will be generated and an email will be sent to the user
for the payment received. The invoice will contain the amount.

  
  Front End :-
        
        Html
        CSS
        JS


Payment Gateway Used:- 

    RazorPay
    
project Designed for The sparks Foundation(GRIP)



Designed By:-Anand kumar yadav
    
